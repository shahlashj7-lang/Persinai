package com.persiansearch.app

import kotlin.math.ln
import kotlin.math.sqrt

/** خلاصه‌سازی استخراجی؛ نسخهٔ Kotlin از summarizer.py */
object Summarizer {
    private val STOP: Set<String> = (
        "a an the and or but if then else of to in on at by for with about as into like " +
            "through after over between out against during without before under around among is " +
            "are was were be been being have has had do does did will would can could should may " +
            "might must this that these those it its i you he she we they them his her our their " +
            "my your me him us what which who whom whose when where why how not no nor so than too " +
            "very just also from up down off again further once here there all any both each few " +
            "more most other some such only own same " +
            "و در به از که این را با است برای آن یک هم کرد شد می های ها بود تا یا اما اگر بر " +
            "نیز هر دو خود آنها ما من تو او شده شود باشد کند کنند"
        ).split(" ").filter { it.isNotEmpty() }.toSet()

    private val WORD = Regex("[\\p{L}\\p{N}_]+")
    private val SENT = Regex("(?<=[.!?؟۔])\\s+|\\n+")

    private fun words(text: String): List<String> =
        WORD.findAll(text).map { it.value.lowercase() }.toList()

    fun queryTerms(queries: List<String>): Set<String> {
        val terms = HashSet<String>()
        for (q in queries) {
            for (w in words(q)) {
                if (w !in STOP && w.length > 2) terms.add(w)
            }
        }
        return terms
    }

    private fun splitSentences(text: String): List<String> =
        SENT.split(text).map { it.trim() }.filter { it.length in 40..400 }

    /** برمی‌گرداند: (جمله‌های منتخب به ترتیب ظهور، اندیس بهترین جمله در همان لیست) */
    fun summarize(text: String, terms: Set<String>, n: Int = 3): Pair<List<String>, Int> {
        val sentences = splitSentences(text)
        if (sentences.isEmpty()) return Pair(emptyList(), 0)

        val freq = HashMap<String, Int>()
        for (w in words(text)) {
            if (w !in STOP && w.length > 2) freq[w] = (freq[w] ?: 0) + 1
        }
        val maxFreq = freq.values.maxOrNull() ?: return Pair(emptyList(), 0)

        val scored = ArrayList<Pair<Double, Int>>()
        for ((idx, sent) in sentences.withIndex()) {
            val ws = words(sent).filter { it !in STOP && it.length > 2 }
            if (ws.isEmpty()) continue
            var sum = 0.0
            for (w in ws) sum += (freq[w] ?: 0).toDouble()
            val base = sum / sqrt(ws.size.toDouble())
            val overlap = ws.toSet().count { it in terms }
            scored.add(Pair(base + 5.0 * overlap * ln(1.0 + maxFreq), idx))
        }
        if (scored.isEmpty()) return Pair(emptyList(), 0)

        val top = scored
            .sortedWith(compareByDescending<Pair<Double, Int>> { it.first }.thenByDescending { it.second })
            .take(n)
        val bestIdx = top[0].second
        val chosen = top.map { it.second }.sorted()
        return Pair(chosen.map { sentences[it] }, chosen.indexOf(bestIdx))
    }
}
