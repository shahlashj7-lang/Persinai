package com.persiansearch.app

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * صدای فارسی «دلارا» از سرویس Edge (همان چیزی که edge-tts در نسخهٔ پایتون استفاده می‌کند).
 * اگر سرویس در دسترس نباشد یا پروتکل آن تغییر کرده باشد، null برمی‌گرداند و برنامه
 * به صدای خود اندروید برمی‌گردد.
 */
object EdgeTts {
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val CHROMIUM = "130.0.2849.68"
    private const val VOICE = "Microsoft Server Speech Text to Speech Voice (fa-IR, DilaraNeural)"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun secMsGec(): String {
        var ticks = System.currentTimeMillis() / 1000 + 11_644_473_600L
        ticks -= ticks % 300
        val input = (ticks * 10_000_000L).toString() + TOKEN
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.US_ASCII))
        return digest.joinToString("") { "%02X".format(it) }
    }

    private fun timestamp(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date()) + " GMT+0000 (Coordinated Universal Time)"
    }

    private fun esc(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    /** متن را به یک فایل mp3 در cacheDir تبدیل می‌کند؛ در صورت شکست null. */
    fun synthesize(text: String, cacheDir: File): File? {
        val url = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
            "?TrustedClientToken=$TOKEN" +
            "&ConnectionId=${UUID.randomUUID().toString().replace("-", "")}" +
            "&Sec-MS-GEC=${secMsGec()}" +
            "&Sec-MS-GEC-Version=1-$CHROMIUM"
        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
            )
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()

        val audio = ByteArrayOutputStream()
        val done = CountDownLatch(1)
        var failed = false
        val requestId = UUID.randomUUID().toString().replace("-", "")

        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(
                    "X-Timestamp:${timestamp()}\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":" +
                        "{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"}," +
                        "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                )
                val ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='fa-IR'>" +
                    "<voice name='$VOICE'><prosody pitch='+0Hz' rate='+0%' volume='+0%'>" +
                    esc(text) + "</prosody></voice></speak>"
                webSocket.send(
                    "X-RequestId:$requestId\r\n" +
                        "Content-Type:application/ssml+xml\r\n" +
                        "X-Timestamp:${timestamp()}Z\r\n" +
                        "Path:ssml\r\n\r\n" + ssml
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) done.countDown()
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val b = bytes.toByteArray()
                if (b.size < 2) return
                val headerLen = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
                if (2 + headerLen > b.size) return
                val header = String(b, 2, headerLen, Charsets.UTF_8)
                if (header.contains("Path:audio")) audio.write(b, 2 + headerLen, b.size - 2 - headerLen)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                failed = true
                done.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                done.countDown()
            }
        })

        done.await(40, TimeUnit.SECONDS)
        ws.close(1000, null)
        if (failed || audio.size() < 1000) return null

        val file = File.createTempFile("tts", ".mp3", cacheDir)
        file.writeBytes(audio.toByteArray())
        return file
    }
}
