package com.persiansearch.app

import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLDecoder
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** خط لولهٔ اصلی: جستجو ← دریافت متن ← خلاصه‌سازی ← ترجمه (نسخهٔ Kotlin از searcher.py و core.py) */
object Pipeline {
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    private const val MAX_PAGE_BYTES = 1_500_000
    private const val MAX_TEXT_CHARS = 20_000

    private class Item(val title: String, val url: String, val snippet: String)

    private fun hasPersian(text: String): Boolean = text.any { it in '\u0600'..'\u06FF' }

    /** ترجمهٔ رایگان گوگل (بدون کلید). خطا را به بالا پرتاب می‌کند. */
    private fun translate(text: String, from: String, to: String): String {
        val body = Jsoup.connect("https://translate.googleapis.com/translate_a/single")
            .userAgent(UA)
            .ignoreContentType(true)
            .timeout(10_000)
            .data("client", "gtx")
            .data("sl", from)
            .data("tl", to)
            .data("dt", "t")
            .data("q", text)
            .execute()
            .body()
        val arr = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val seg = arr.optJSONArray(i) ?: continue
            if (!seg.isNull(0)) sb.append(seg.getString(0))
        }
        return sb.toString().trim()
    }

    private fun realUrl(href: String): String? {
        var h = href
        val i = h.indexOf("uddg=")
        if (i >= 0) {
            h = URLDecoder.decode(h.substring(i + 5).substringBefore("&"), "UTF-8")
        } else if (h.startsWith("//")) {
            h = "https:$h"
        }
        return if (h.startsWith("http://") || h.startsWith("https://")) h else null
    }

    private fun ddg(q: String, max: Int): List<Item> {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/")
            .userAgent(UA)
            .timeout(10_000)
            .data("q", q)
            .post()
        val out = ArrayList<Item>()
        for (r in doc.select("div.result")) {
            if (r.hasClass("result--ad")) continue
            val a = r.selectFirst("a.result__a") ?: continue
            val url = realUrl(a.attr("href")) ?: continue
            val title = a.text().ifBlank { url }
            val snippet = r.selectFirst(".result__snippet")?.text() ?: ""
            out.add(Item(title, url, snippet))
            if (out.size >= max) break
        }
        return out
    }

    private fun searchWeb(query: String, max: Int = 6): Triple<List<Item>, List<String>, String?> {
        val queries = arrayListOf(query)
        if (hasPersian(query)) {
            try {
                val en = translate(query, "fa", "en")
                if (en.isNotBlank() && !en.equals(query.trim(), ignoreCase = true)) queries.add(en)
            } catch (e: Exception) {
                // ترجمهٔ سؤال اختیاری است
            }
        }
        val perQuery = ArrayList<List<Item>>()
        var error: String? = null
        for (q in queries) {
            try {
                perQuery.add(ddg(q, max))
            } catch (e: Exception) {
                perQuery.add(emptyList())
                error = e.message ?: "error"
            }
        }
        val results = ArrayList<Item>()
        val seen = HashSet<String>()
        val longest = perQuery.maxOfOrNull { it.size } ?: 0
        for (i in 0 until longest) {          // ترکیب نوبتی نتایج دو جستجو
            for (group in perQuery) {
                val item = group.getOrNull(i) ?: continue
                if (seen.add(item.url)) results.add(item)
            }
        }
        return Triple(results.take(max), queries, if (results.isEmpty()) error else null)
    }

    private fun fetchText(url: String): String {
        return try {
            val doc = Jsoup.connect(url)
                .userAgent(UA)
                .timeout(8_000)
                .maxBodySize(MAX_PAGE_BYTES)
                .followRedirects(true)
                .get()
            doc.select("script, style, nav, footer, aside, header, form").remove()
            val text = doc.select("p").map { it.text().trim() }
                .filter { it.length > 40 }
                .joinToString("\n")
            text.take(MAX_TEXT_CHARS)
        } catch (e: Exception) {
            ""
        }
    }

    private fun toPersian(sentences: List<String>): Pair<List<String>, Boolean> {
        if (sentences.isEmpty()) return Pair(emptyList(), true)
        return try {
            val out = sentences.map { s ->
                if (hasPersian(s)) s else translate(s, "auto", "fa").ifBlank { s }
            }
            Pair(out, true)
        } catch (e: Exception) {
            Pair(sentences, false)
        }
    }

    private fun process(item: Item, text: String, terms: Set<String>): JSONObject {
        val body = if (text.length > 200) text else item.snippet + "\n" + text
        val summary = Summarizer.summarize(body, terms, 3)
        var sentences = summary.first
        var best = summary.second
        if (sentences.isEmpty() && item.snippet.isNotEmpty()) {
            sentences = listOf(item.snippet)
            best = 0
        }
        val (fa, ok) = toPersian(sentences)
        val key = if (fa.isNotEmpty() && ok && fa.size == sentences.size) fa[best] else (fa.firstOrNull() ?: "")
        return JSONObject()
            .put("title", item.title)
            .put("url", item.url)
            .put("summary", fa.joinToString(" "))
            .put("key", key)
            .put("translated", ok)
    }

    private fun result(query: String, overall: String, sources: List<JSONObject>, notes: List<String>): JSONObject {
        val srcArr = JSONArray()
        sources.forEach { srcArr.put(it) }
        val noteArr = JSONArray()
        notes.forEach { noteArr.put(it) }
        return JSONObject()
            .put("query", query)
            .put("overall", overall)
            .put("sources", srcArr)
            .put("notes", noteArr)
    }

    fun run(rawQuery: String): JSONObject {
        val query = rawQuery.trim()
        val (results, used, error) = searchWeb(query)
        if (results.isEmpty()) {
            val note = if (error != null) {
                "جستجو انجام نشد (احتمالاً اینترنت قطع است، فیلترشکن لازم است، یا موتور جستجو " +
                    "موقتاً محدودیت گذاشته). چند دقیقه بعد دوباره امتحان کنید."
            } else {
                "نتیجه‌ای پیدا نشد؛ سؤال را کمی تغییر دهید."
            }
            return result(query, "", emptyList(), listOf(note))
        }

        val terms = Summarizer.queryTerms(used)
        val pool = Executors.newFixedThreadPool(6)
        try {
            val texts = results.map { r -> pool.submit(Callable { fetchText(r.url) }) }.map { it.get() }
            val sources = results.indices
                .map { i -> pool.submit(Callable { process(results[i], texts[i], terms) }) }
                .map { it.get() }
                .filter { it.getString("summary").isNotEmpty() }

            if (sources.isEmpty()) {
                return result(
                    query, "", emptyList(),
                    listOf("از صفحه‌های پیداشده متنی برای خلاصه کردن به دست نیامد؛ سؤال را تغییر دهید.")
                )
            }
            val notes = ArrayList<String>()
            if (sources.any { !it.getBoolean("translated") }) {
                notes.add("ترجمه‌ی رایگان در دسترس نبود؛ بعضی خلاصه‌ها به زبان اصلی نمایش داده شده‌اند.")
            }
            val overall = sources.take(5).map { it.getString("key") }.filter { it.isNotEmpty() }.joinToString(" ")
            return result(query, overall, sources, notes)
        } finally {
            pool.shutdown()
        }
    }
}
