package com.persiansearch.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newCachedThreadPool()

    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentText = ""
    @Volatile private var speakToken = 0

    private var recognizer: SpeechRecognizer? = null
    private var pendingListen = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        // لینک منبع‌ها در مرورگر گوشی باز شود، نه داخل برنامه
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (e: Exception) {
                    }
                    return true
                }
                return false
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    // ---------- ارتباط با جاوااسکریپت صفحه ----------
    private fun callJs(fn: String, arg: String) {
        val literal = JSONObject.quote(arg)
        runOnUiThread { web.evaluateJavascript("window.$fn($literal)", null) }
    }

    private fun state(s: String) = callJs("onSpeakState", s)

    inner class Bridge {
        @JavascriptInterface
        fun search(q: String) {
            executor.execute {
                val json = try {
                    Pipeline.run(q.take(300)).toString()
                } catch (e: Exception) {
                    JSONObject()
                        .put("query", q)
                        .put("overall", "")
                        .put("sources", JSONArray())
                        .put("notes", JSONArray().put("خطای غیرمنتظره: " + (e.message ?: "")))
                        .toString()
                }
                callJs("onSearchResult", json)
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread { startSpeak(text) }
        }

        @JavascriptInterface
        fun stopSpeaking() {
            runOnUiThread { stopAudio() }
        }

        @JavascriptInterface
        fun listen() {
            runOnUiThread { startListening() }
        }

        @JavascriptInterface
        fun stopListening() {
            runOnUiThread { recognizer?.stopListening() }
        }
    }

    // ---------- خروجی صوتی ----------
    private fun stopAudio() {
        speakToken++
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        tts?.stop()
        state("end")
    }

    private fun startSpeak(text: String) {
        stopAudio()
        val my = speakToken
        currentText = text
        state("start")
        executor.execute {
            val file = try {
                EdgeTts.synthesize(text.take(1500), cacheDir)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (my != speakToken) {
                    file?.delete()
                } else if (file == null || !playFile(file, my)) {
                    nativeSpeak(text, my)
                }
            }
        }
    }

    private fun playFile(file: File, my: Int): Boolean {
        return try {
            val mp = MediaPlayer()
            mp.setDataSource(file.path)
            mp.setOnCompletionListener {
                if (my == speakToken) state("end")
                it.release()
                if (player === it) player = null
                file.delete()
            }
            mp.setOnErrorListener { _, _, _ ->
                if (my == speakToken) nativeSpeak(currentText, my)
                true
            }
            mp.prepare()
            mp.start()
            player = mp
            true
        } catch (e: Exception) {
            false
        }
    }

    /** صدای خود اندروید (اگر صدای فارسی روی گوشی نصب باشد) */
    private fun nativeSpeak(text: String, my: Int) {
        if (my != speakToken) return
        val engine = tts
        if (engine == null) {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsReady = true
                    nativeSpeak(text, my)
                } else {
                    state("nofa")
                }
            }
            return
        }
        if (!ttsReady) return
        val r = engine.setLanguage(Locale("fa", "IR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            state("nofa")
            return
        }
        val parts = text.chunked(3000)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "last$my" && my == speakToken) state("end")
            }
            override fun onError(utteranceId: String?) {
                if (my == speakToken) state("end")
            }
        })
        parts.forEachIndexed { i, p ->
            val id = if (i == parts.lastIndex) "last$my" else "p$my-$i"
            engine.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    // ---------- ورودی صوتی ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            callJs("onVoiceError", "no-service")
            return
        }
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                val code = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    else -> "error"
                }
                callJs("onVoiceError", code)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) {
                    callJs("onVoiceError", "no-speech")
                } else {
                    callJs("onVoiceText", JSONObject().put("text", t).put("final", true).toString())
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    callJs("onVoiceText", JSONObject().put("text", t).put("final", false).toString())
                }
            }
        })
        recognizer = rec
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        rec.startListening(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && pendingListen) {
            pendingListen = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening()
            } else {
                callJs("onVoiceError", "not-allowed")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speakToken++
        executor.shutdownNow()
        try {
            player?.release()
        } catch (e: Exception) {
        }
        tts?.shutdown()
        recognizer?.destroy()
    }
}
